#
# Example file for working with date information
# LinkedIn Learning Python course by Joe Marini
#



def main():
    ## DATE OBJECTS
    # TODO: Get today's date from the simple today() method from the date class


    # TODO: print out the date's individual components

    
    # TODO: retrieve today's weekday (0=Monday, 6=Sunday)

    
    ## DATETIME OBJECTS
    # TODO: Get today's date from the datetime class

    
    # TODO: Get the current time

 

  
if __name__ == "__main__":
    main()
  